# installation
default["sensu"]["enterprise"]["version"] = "1.5.2-1"
default["sensu"]["enterprise"]["use_unstable_repo"] = false
default["sensu"]["enterprise"]["log_level"] = "info"
default["sensu"]["enterprise"]["heap_size"] = "2048m"
